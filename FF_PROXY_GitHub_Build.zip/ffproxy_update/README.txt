FF PROXY — projeto Android inicial

O que faz:
- Interface simples para Android.
- Permite informar host e porta de um proxy.
- Testa a disponibilidade TCP do servidor e mostra o tempo de resposta.

Limitações importantes:
- Isto NÃO é um VPN nem encaminha o tráfego do Free Fire.
- Não injeta arquivos, não modifica o jogo e não oferece anti-ban.
- Use apenas servidores proxy confiáveis e autorizados.

Como gerar o APK:
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Se necessário, instale Android SDK 35 e JDK 17.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de debug ficará em app/build/outputs/apk/debug/.

Para uso real como VPN seria necessário implementar Android VpnService, consentimento explícito do usuário e um servidor compatível; isso não está incluído neste protótipo.
