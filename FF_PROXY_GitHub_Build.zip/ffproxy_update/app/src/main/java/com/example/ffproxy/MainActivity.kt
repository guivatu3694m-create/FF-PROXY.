package com.example.ffproxy

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var host: EditText
    private lateinit var port: EditText
    private lateinit var status: TextView
    private lateinit var connect: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 12, 20)
        window.navigationBarColor = Color.rgb(10, 12, 20)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 24)
            setBackgroundColor(Color.rgb(10, 12, 20))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER }
        layout.addView(label("FF PROXY", 30f, Color.rgb(0, 220, 180)))
        layout.addView(label("CONFIGURAÇÃO DE CONEXÃO", 13f, Color.LTGRAY))
        host = EditText(this).apply {
            hint = "Endereço do proxy (ex.: 192.0.2.1)"
            setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        port = EditText(this).apply {
            hint = "Porta (ex.: 8080)"; inputType = 2
            setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        layout.addView(host, fieldParams())
        layout.addView(port, fieldParams())
        connect = Button(this).apply {
            text = "TESTAR CONEXÃO"
            setOnClickListener { testProxy() }
        }
        layout.addView(connect)
        status = label("Status: aguardando configuração", 15f, Color.YELLOW)
        status.setPadding(0, 28, 0, 12)
        layout.addView(status)
        layout.addView(label("Este app testa se o servidor proxy responde.\nNão injeta arquivos nem altera o Free Fire.", 13f, Color.LTGRAY))
        setContentView(layout)
    }

    private fun fieldParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = 12 }

    private fun testProxy() {
        val address = host.text.toString().trim()
        val portNumber = port.text.toString().trim().toIntOrNull()
        if (address.isBlank() || portNumber == null || portNumber !in 1..65535) {
            status.text = "Informe um endereço e uma porta válidos."
            return
        }
        connect.isEnabled = false
        status.text = "Status: testando..."
        thread {
            val start = System.nanoTime()
            val result = try {
                Socket().use { it.connect(InetSocketAddress(address, portNumber), 4000) }
                "Conexão TCP disponível — ${((System.nanoTime() - start) / 1_000_000)} ms"
            } catch (e: Exception) {
                "Não foi possível conectar. Confira o host, a porta e a rede."
            }
            runOnUiThread {
                status.text = result
                connect.isEnabled = true
            }
        }
    }
}
